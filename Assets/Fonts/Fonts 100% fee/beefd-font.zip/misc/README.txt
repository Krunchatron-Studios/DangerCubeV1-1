
  Developed in 2016
  ________________________________________________________________

  Email me at ryqol@outlook.com for any questions or to request a glyph in this font.

  This uses the SIL Open Font License (OFL), which can be read at scripts.sil.org/OFL

  Created by Lewis Bauer (Extram Studios)